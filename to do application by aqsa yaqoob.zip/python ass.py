todo_list = []

def show_menu():
    print("\n--- TO-DO LIST MENU ---")
    print("1. Add To-Do")
    print("2. View To-Do List")
    print("3. Delete To-Do by number")
    print("4. Clear All To-Dos")
    print("5. Exit")

while True:
    show_menu()
    choice = input("Enter your choice (1-5): ")

    if choice == '1':
        title = input("Enter To-Do Title: ")
        date = input("Enter Date (YYYY-MM-DD): ")
        todo = {"title": title, "date": date}
        todo_list.append(todo)
        print("To-Do added successfully!")

    elif choice == '2':
        if not todo_list:
            print("To-Do list is empty.")
        else:
            print("\nYour To-Do List:")
            for i, todo in enumerate(todo_list):
                print(f"{i+1}. {todo['title']} (Due: {todo['date']})")

    elif choice == '3':
        num = int(input("Enter To-Do number to delete: "))
        if 0 < num <= len(todo_list):
            deleted = todo_list.pop(num - 1)
            print(f"Deleted: {deleted['title']} (Due: {deleted['date']})")
        else:
            print("Invalid number. Please try again.")
    elif choice == '4':
        todo_list.clear()
        print("All To-Dos cleared!")

    elif choice == '5':
        print("Exiting... Goodbye!")
        break

    else:
        print("Invalid choice. Please enter a number (1-5).")